﻿// ECMAScript 5 strict mode
"use strict";

assert2(cr, "cr namespace not created");
assert2(cr.plugins_, "cr.plugins_ not created");

/////////////////////////////////////
// Plugin class
// *** CHANGE THE PLUGIN ID HERE *** - must match the "id" property in edittime.js
//          vvvvvvvv
cr.plugins_.Bit = function(runtime)
{
	this.runtime = runtime;
};

(function ()
{
	/////////////////////////////////////
	// *** CHANGE THE PLUGIN ID HERE *** - must match the "id" property in edittime.js
	//                            vvvvvvvv
	var pluginProto = cr.plugins_.Bit.prototype;
		
	/////////////////////////////////////
	// Object type class
	pluginProto.Type = function(plugin)
	{
		this.plugin = plugin;
		this.runtime = plugin.runtime;
	};

	var typeProto = pluginProto.Type.prototype;

	// called on startup for each object type
	typeProto.onCreate = function()
	{
	};

	/////////////////////////////////////
	// Instance class
	pluginProto.Instance = function(type)
	{
		this.type = type;
		this.runtime = type.runtime;
		
		// any other properties you need, e.g...
		// this.myValue = 0;
	};
	
	var instanceProto = pluginProto.Instance.prototype;

	// called whenever an instance is created
	instanceProto.onCreate = function()
	{
		// note the object is sealed after this call; ensure any properties you'll ever need are set on the object
		// e.g...
		// this.myValue = 0;
	};
	
	// only called if a layout object - draw to a canvas 2D context
	instanceProto.draw = function(ctx)
	{
	};
	
	// only called if a layout object in WebGL mode - draw to the WebGL context
	// 'glw' is not a WebGL context, it's a wrapper - you can find its methods in GLWrap.js in the install
	// directory or just copy what other plugins do.
	instanceProto.drawGL = function (glw)
	{
	};

	//////////////////////////////////////
	// Conditions
	pluginProto.cnds = {};
	var cnds = pluginProto.cnds;

	// the example condition
	cnds.checkMask = function (bitfield,mask)
	{
		bitfield = parseInt(bitfield);
		mask = parseInt(mask);
		// return true if number is positive
		return bitfield & mask;
	};
	
	cnds.isOne = function (bitfield,position)
	{
		bitfield = parseInt(bitfield);
		// return true if number is positive
		return bitfield & (1 << position);
	};
		
	cnds.isPowerOfTwo = function (number)
	{
		number = parseInt(number);
		// return true if number is positive
		return ((number & (number*-1)) == number);
	};
	
	//////////////////////////////////////
	// Actions
	pluginProto.acts = {};
	var acts = pluginProto.acts;

	// the example action
	/*
	acts.MyAction = function (myparam)
	{
		// alert the message
		alert(myparam);
	};
	*/
	/////////////////////////////	/////////
	// Expressions
	pluginProto.exps = {};
	var exps = pluginProto.exps;
	

     // the example expression
     exps.AND = function (ret,a,b)     // 'ret' must always be the first parameter - always return the expression's result through it!
     {
		a = parseInt(a);
		b = parseInt(b);
        var val = a & b;         
        if (arguments.length > 3)
        {
            var i, cnt=arguments.length;
            for(i=3; i<cnt; i+=1)
            {
                val &= arguments[ i ];
            }
        }
        ret.set_int(val);                    // return our value
     };
	
    exps.CharToInt = function(ret, c)
    {
    	ret.set_int(c.charCodeAt(0))
    }

    exps.IntToChar = function(ret, i)
    {
    	i = parseInt(i)
    	ret.set_string(String.fromCharCode(i));
    }

	exps.OR = function (ret,a,b)	// 'ret' must always be the first parameter - always return the expression's result through it!
	{
		a = parseInt(a);
		b = parseInt(b);
        var val = a | b;         
        if (arguments.length > 3)
        {
            var i, cnt=arguments.length;
            for(i=3; i<cnt; i+=1)
            {
                val |= arguments[ i ];
            }
        }
        ret.set_int(val); 			// return our value
	};
	
	exps.XOR = function (ret,a,b)	// 'ret' must always be the first parameter - always return the expression's result through it!
	{
		a = parseInt(a);
		b = parseInt(b);
        var val = a ^ b;         
        if (arguments.length > 3)
        {
            var i, cnt=arguments.length;
            for(i=3; i<cnt; i+=1)
            {
                val ^= arguments[ i ];
            }
        }
        ret.set_int(val); 				// return our value
	};
	
	exps.NOT = function (ret,a)	// 'ret' must always be the first parameter - always return the expression's result through it!
	{
		a = parseInt(a);
		ret.set_int(~a);				// return our value
	};
	
	exps.lShift = function (ret,value,pos)	// 'ret' must always be the first parameter - always return the expression's result through it!
	{
		value = parseInt(value);
		ret.set_int(value << pos);				// return our value
	};
	
	exps.rShift = function (ret,value,pos)	// 'ret' must always be the first parameter - always return the expression's result through it!
	{
		value = parseInt(value);
		ret.set_int(value  >> pos);				// return our value
	};
	
	exps.set1 = function (ret,value,pos)	// 'ret' must always be the first parameter - always return the expression's result through it!
	{
		value = parseInt(value);
		ret.set_int(value | (1 << pos));				// return our value
	};
		
	exps.set0 = function (ret,value,pos)	// 'ret' must always be the first parameter - always return the expression's result through it!
	{
		value = parseInt(value);
		ret.set_int(value & ~(1 << pos));				// return our value
	};
		
	exps.toggle = function (ret,value,pos)	// 'ret' must always be the first parameter - always return the expression's result through it!
	{
		value = parseInt(value);
		ret.set_int(value ^ (1 << pos));				// return our value
	};

}());