﻿function GetBehaviorSettings() {
  return {
    "name": "Boids", 		// as appears in 'add behavior' dialog, can be changed as long as "id" stays the same
    "id": "boids", 		// this is used to identify this behavior and is saved to the project; never change it
    "version": "1.0", 				// (float in x.y format) Behavior version - C2 shows compatibility warnings based on this
    "description": "Simulated flocking movement based on Craig Reynolds' boids model - http://www.red3d.com/cwr/boids/",
    "author": "Alastair Aitchison",
    "help url": "<your website or a manual entry on Scirra.com>",
    "category": "Movements", 			// Prefer to re-use existing categories, but you can set anything here
    "flags": 0						// uncomment lines to enable flags...
    //	| bf_onlyone			// can only be added once to an object, e.g. solid
  };
};

AddNumberParam("Target X", "The target X to flock to.");
AddNumberParam("Target Y", "The target Y to flock to.");
AddObjectParam("Flock with", "The object(s) to flock with");
AddNumberParam("Target Priority", "The priority given to seeking the target. e.g. 1.0");
AddNumberParam("Seperation Priority", "The priority of retaining seperation from close neighbours. e.g. 50");
AddNumberParam("Alignment Priority", "The priority of aligning to the average direction of flockmates. e.g. 30");
AddNumberParam("Cohesion Priority", "The priority of remaining close to the centre of the flock. e.g. 20");
AddNumberParam("Seperation Distance", "The seperation distance to attempt to maintain from other flockmates.");
AddAction(1, af_none, "Flock", "Steering Behaviours", "Flock with {2} to the position (<i>{0}</i>,<i>{1}</i>)", "Flock behaviour", "Flock");

////////////////////////////////////////
ACESDone();

////////////////////////////////////////
// Array of property grid properties for this plugin
var property_list = [
  new cr.Property(ept_float, "maxSpeed", 100, "The maximum speed of travel."),
  new cr.Property(ept_float, "maxForce", 1, "The maximum steering force that will be applied.")
	];

// Called by IDE when a new behavior type is to be created
function CreateIDEBehaviorType() {
  return new IDEBehaviorType();
}

// Class representing a behavior type in the IDE
function IDEBehaviorType() {
  assert2(this instanceof arguments.callee, "Constructor called as a function");
}

// Called by IDE when a new behavior instance of this type is to be created
IDEBehaviorType.prototype.CreateInstance = function (instance) {
  return new IDEInstance(instance, this);
}

// Class representing an individual instance of the behavior in the IDE
function IDEInstance(instance, type) {
  assert2(this instanceof arguments.callee, "Constructor called as a function");

  // Save the constructor parameters
  this.instance = instance;
  this.type = type;

  // Set the default property values from the property table
  this.properties = {};

  
  for (var i = 0; i < property_list.length; i++)
  this.properties[property_list[i].name] = property_list[i].initial_value;

}

// Called by the IDE after all initialization on this instance has been completed
IDEInstance.prototype.OnCreate = function () {
}

// Called by the IDE after a property has been changed
IDEInstance.prototype.OnPropertyChanged = function (property_name) {
}
