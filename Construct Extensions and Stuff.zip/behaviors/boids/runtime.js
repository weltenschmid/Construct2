﻿// ECMAScript 5 strict mode
"use strict";

assert2(cr, "cr namespace not created");
assert2(cr.behaviors, "cr.behaviors not created");

/////////////////////////////////////
// Behavior class
// *** CHANGE THE BEHAVIOR ID HERE *** - must match the "id" property in edittime.js
//           vvvvvvvvvv
cr.behaviors.boids = function(runtime)
{
	this.runtime = runtime;
};

(function ()
{
	// *** CHANGE THE BEHAVIOR ID HERE *** - must match the "id" property in edittime.js
	//                               vvvvvvvvvv
	var behaviorProto = cr.behaviors.boids.prototype;
		
	/////////////////////////////////////
	// Behavior type class
	behaviorProto.Type = function(behavior, objtype)
	{
		this.behavior = behavior;
		this.objtype = objtype;
		this.runtime = behavior.runtime;
	};
	
	var behtypeProto = behaviorProto.Type.prototype;

	behtypeProto.onCreate = function()
	{
	};

	/////////////////////////////////////
	// Behavior instance class
	behaviorProto.Instance = function(type, inst)
	{
		this.type = type;
		this.behavior = type.behavior;
		this.inst = inst;				// associated object instance to modify
		this.runtime = type.runtime;

    // Define additional properties required for autonomous steering calculations
    // Velocity
    this.dx = 0;
		this.dy = 0;
    // Limits
    this.maxForce = 0.1;
    this.maxSpeed = 5;
    // Steering force
    this.sx = 0;
    this.sy = 0;

    this.enabled = true;
	};
	
	var behinstProto = behaviorProto.Instance.prototype;

  behinstProto.getSpeed = function()
	{
		return Math.sqrt(this.dx * this.dx + this.dy * this.dy);
	};
	
	behinstProto.getAngle = function()
	{
		return Math.atan2(this.dy, this.dx);
	};

	behinstProto.onCreate = function()
	{
		// Load properties
		this.maxSpeed = this.properties[0];
		this.maxForce = this.properties[1];
		// object is sealed after this call, so make sure any properties you'll ever need are created, e.g.
		// this.myValue = 0;
	};

	behinstProto.tick = function ()
	{
    // Calculate magnitude of steering force
    var force = Math.sqrt(this.sx * this.sx + this.sy * this.sy);

    // Truncate if greater than maxForce
    var scaleFactor = (force > this.maxForce) ? this.maxForce / force : 1;
    this.sx = this.sx * scaleFactor;
    this.sy = this.sy * scaleFactor;

    // Accelerate
    this.dx = this.dx + this.sx;
    this.dy = this.dy + this.sy;

    // Calculate magnitude of current speed
    var speed = Math.sqrt(this.dx * this.dx + this.dy * this.dy);

    // Truncate speed if over max speed
    if(speed > this.maxSpeed) {
      var scaleFactor = this.maxSpeed / speed;
      this.dx = this.dx * scaleFactor;
      this.dy = this.dy * scaleFactor;
    }
    
    // dt is the amount of time passed since the last tick
    var dt = this.runtime.getDt(this.inst);
    // Scale the velocity by the amount of elapsed time
		var mx = this.dx * dt;
		var my = this.dy * dt;

    // Update position
    this.inst.x += mx;
	  this.inst.y += my;

    // Update angle
    this.inst.angle = this.getAngle();

    // IMPORTANT - always call after updating position or angle
    this.inst.set_bbox_changed();

    // Reset the steering force for the next tick
    this.sx = 0;
    this.sy = 0;
	};

	//////////////////////////////////////
	// Conditions
	function Cnds() {};
	behaviorProto.cnds = new Cnds();

	//////////////////////////////////////
	// Actions
	function Acts() {};

  Acts.prototype.Flock = function (targetX, targetY, flockTargetType, targetPriority, seperationPriority, alignmentPriority, cohesionPriority, seperationDistance)
	{
    // Flocking behaviour moves an entity by balancing several forces:
    // 1.) To move towards the target (target)
    // 2.) To not collide with other members of the flock (seperation)
    // 3.) To move in the same direction as other members of the flock (alignment)
    // 4.) To remain relatively close to the centre of the flock (cohesion)

    // In this function, each force is weighted by their respective priority and then combined
    // to calculate a single overall desired velocity.

    // 1.) TARGET

    // Calculate the deltas to the target position
    var deltax = targetX - this.inst.x;
    var deltay = targetY - this.inst.y;

    // Normalise
    var normalx = 0;
    var normaly = 0;
    var length = Math.sqrt(deltax * deltax + deltay * deltay);
    if (length > 0) {
      normalx = deltax / length;
      normaly = deltay / length;
    }

    // Head towards the target x,y at maximum allowed speed, adjusted for priorty
    var desiredVelocityX = normalx * this.maxSpeed * targetPriority;
    var desiredVelocityY = normaly * this.maxSpeed * targetPriority;

    // Group behaviours must be calculated by looping through and considering relationship
    // between this entity and every other member of the flock
    var flockers = flockTargetType.instances;
    var count = flockers.length;
    for (var i = 0; i < count; i++) {
      var a = flockers[i];

      // Don't flock yourself!
      if (a == this.inst) { continue; }

      // Calculate distance to other flock member
      var deltax = this.inst.x - a.x;
      var deltay = this.inst.y - a.y;
      var distance = Math.sqrt(deltax * deltax + deltay * deltay);

      // Normalise
      var normalx = 0;
      var normaly = 0;
      if (distance > 0) {
        normalx = deltax / distance;
        normaly = deltay / distance;
      }

      // Do not flock with actors who are far away
      //if (distance > seperationDistance * 2)
      //  continue;

      // SEPERATION: steer to avoid crowding local flockmates (short range repulsion)
      var seperationX = 0;
      var seperationY = 0;
      if (distance == 0) { distance = 0.0000001;} // Prevent div/0!
      if (distance < seperationDistance)
      {
        // Calculate seperation force, adjusted for priority.
        seperationX = normalx / (distance / seperationDistance) * seperationPriority;
        seperationY = normaly / (distance / seperationDistance) * seperationPriority;
        // Add seperation to desired velocity
        desiredVelocityX = desiredVelocityX + seperationX;
        desiredVelocityY = desiredVelocityY + seperationY;
      }

      // COHESION: steer towards average position of neighbors (long range attraction)
      // Calculate cohseive force, adjusted for priority.
      var cohesionX = -normalx * cohesionPriority / count;
      var cohesionY = -normaly * cohesionPriority / count;
      // Add cohesion to desired velocity, adjusted for priority.
      desiredVelocityX = desiredVelocityX + cohesionX;
      desiredVelocityY = desiredVelocityY + cohesionY;

      // ALIGNMENT: steer towards average heading of neighbors
      // Calculate alignment force, adjusted for priority.
      var alignmentX = Math.cos(cr.to_radians(a.angle)) * alignmentPriority / count;
      var alignmentY = Math.sin(cr.to_radians(a.angle)) * alignmentPriority / count;
      // Add alignment to desired velocity, adjusted for priority.
      desiredVelocityX = desiredVelocityX + alignmentX;
      desiredVelocityY = desiredVelocityY + alignmentY;
    }

    // Calculate steering force as the difference between
    // desired velocity and actual current velocity
    var sx = desiredVelocityX - this.dx;
    var sy = desiredVelocityY - this.dy;

    // Calculate magnitude of steering force
    var force = Math.sqrt(sx * sx + sy * sy);
    // Truncate if greater than maxForce
    var scaleFactor = (force > this.maxForce) ? this.maxForce / force : 1;

    // Set the steering force
    this.sx = sx * scaleFactor;
    this.sy = sy * scaleFactor;
	};

	// ... other actions here ...
  Acts.prototype.SetEnabled = function (en)
	{
		this.enabled = (en === 1);
	};
	
	behaviorProto.acts = new Acts();

	//////////////////////////////////////
	// Expressions
	function Exps() {};
	behaviorProto.exps = new Exps();
	
}());