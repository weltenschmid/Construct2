[Rex's ACE tables](https://rexrainbow.github.io/C2RexDoc/c2rexpluginsACE/index.html "c2rexpluginsACE")  
[Repo](https://github.com/rexrainbow/C2RexDoc/blob/master/repo/index.md "repo")  
[c2rexplugins.weebly.com](https://rexrainbow.github.io/C2RexDoc/c2rexplugins.weebly.com/index.html "c2rexplugins.weebly.com")  
[New plugin document(WIP)](https://rexrainbow.github.io/C2RexDoc/plugins.md/index.html)
